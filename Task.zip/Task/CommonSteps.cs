﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TechTalk.SpecFlow;


namespace Task
{
    [Binding]
    public class CommonSteps
    {
        IWebDriver driver = WebDriverSingleton.getInstance();
        IWebElement element;
        LoginPage LoginPage = new LoginPage();
        MainPage MainPage = new MainPage();

        [Given(@"the web browser is opened")]
        public void GivenTheWebBrowserIsOpened()
        {
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(50);
            driver.Navigate().GoToUrl("https://orangehrm-demo-6x.orangehrmlive.com");
            driver.Manage().Window.Maximize();
        }

        [Given(@"user log in using credentials")]
        public void GivenUserLogInUsingCredentials(Table table)
        {
            GivenTheWebBrowserIsOpened();
            element = driver.FindElement(By.XPath(LoginPage.userName));
            element.Clear();
            element.SendKeys(table.Rows[0]["userName"]);
            element = driver.FindElement(By.XPath(LoginPage.password));
            element.Clear();
            element.SendKeys(table.Rows[0]["password"]);
            element = driver.FindElement(By.XPath(LoginPage.loginBtn));
            element.Click();
        }

        [When(@"navigate employee records")]
        public void WhenNavigateEmployeeRecords(Table table)
        {
            element = driver.FindElement(By.XPath(MainPage.timeItemMenu), 3);
            element.Click();
            element = driver.FindElement(By.XPath(MainPage.attendanceItemMenu));
            element.Click();
            //Thread.Sleep(2000);
            element = driver.FindElement(By.XPath(MainPage.EmployeeItemMenu), 5, displayed: true);
            element.Click();
            driver.SwitchTo().Frame(driver.FindElement(By.Id("noncoreIframe"), 5));

            element = driver.FindElement(By.XPath(MainPage.employeeNameInput), 3, displayed: true);
            element.Click();
            element.SendKeys(Keys.Delete);
            element.SendKeys(table.Rows[0]["employeeName"]);

            element = driver.FindElement(By.XPath(MainPage.employeeNameInputText(table.Rows[0]["employeeName"])), 3, displayed: true);
            element.Click();

            element = driver.FindElement(By.XPath(MainPage.attendanceDate));
            element.Click();

            element = driver.FindElement(By.XPath(MainPage.dateText(table.Rows[0]["date"])));
            element.Click();

            element = driver.FindElement(By.XPath(MainPage.viewBtn), 5, displayed: true);
            IJavaScriptExecutor ex = (IJavaScriptExecutor)driver;
            ex.ExecuteScript("arguments[0].click();", element);
        }

        [Then(@"table is empty")]
        public void ThenTableIsEmpty()
        {
            List<IWebElement> lstTdElem = new List<IWebElement>(driver.FindElements(By.XPath(MainPage.tableResults)));
            bool emptyTable = false;
            foreach (var elemTd in lstTdElem)
            {
                if (elemTd.Text.Contains("No attendance records to display"))
                {
                    Console.WriteLine("Table is empty");
                    emptyTable = true;
                    break;
                }
            }
            Assert.IsTrue(emptyTable, "Table contains records");
        }

        [When(@"add employee new record")]
        public void WhenAddEmployeeNewRecord(Table table)
        {
            element = driver.FindElement(By.XPath(MainPage.addBtn));
            element.Click();

            element = driver.FindElement(By.XPath(MainPage.attendanceDate));
            element.Click();

            element = driver.FindElement(By.XPath(MainPage.dateText(table.Rows[0]["date"])));
            element.Click();

            element = driver.FindElement(By.XPath(MainPage.textArea), 2);
            element.SendKeys(table.Rows[0]["note"]);
            element = driver.FindElement(By.XPath(MainPage.punchInOutBtn));
            element.Click();
        }

        [Then(@"table contains new record")]
        public void ThenTableContainsNewRecord(Table table)
        {
            element = driver.FindElement(By.XPath(MainPage.addBtn));
            element = driver.FindElement(By.XPath(MainPage.attendanceDate));
            element.Click();
            element = driver.FindElement(By.XPath(MainPage.dateText(table.Rows[0]["date"])));
            element.Click();
            element = driver.FindElement(By.XPath(MainPage.viewBtn), 2);

            IJavaScriptExecutor ex = (IJavaScriptExecutor)driver;
            ex.ExecuteScript("arguments[0].click();", element);
            Thread.Sleep(3000);

            List<IWebElement> lstTdElem = new List<IWebElement>(driver.FindElements(By.XPath(MainPage.tableResults)));
            bool emptyTable = true;
            foreach (var elemTd in lstTdElem)
            {
                if (elemTd.Text.Contains(table.Rows[0]["note"]))
                {
                    Console.WriteLine("Table is not empty");
                    emptyTable = false;
                    break;
                }
                else
                if (elemTd.Text.Contains("No attendance records to display"))
                {
                        Console.WriteLine("Table is empty");
                        break;
                }
            }
            Assert.IsFalse(emptyTable, "Table is empty");
            GivenTheWebBrowserIsClosed();
        }

        [Given(@"the web browser is closed")]
        public void GivenTheWebBrowserIsClosed()
        {
            driver.Close();
        }

    }
}
