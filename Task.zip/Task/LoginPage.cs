﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using TechTalk.SpecFlow;

namespace Task
{
    public class LoginPage
    {
        public string userName = "//input[@id='txtUsername']";
        public string password = "//input[@id='txtPassword']";
        public string loginBtn = "//input[@id='btnLogin']";
    }
}
