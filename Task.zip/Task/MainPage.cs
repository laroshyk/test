﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task
{
    public class MainPage
    {
        public string timeItemMenu = "//div[@id='menu-content']//span[text()='Time']";
        public string attendanceItemMenu = "//div[@id='menu-content']//span[text()='Attendance']";
        public string EmployeeItemMenu = "//div[@id='menu-content']//a[@id='menu_attendance_viewAttendanceRecord']/span[text()='Employee Records']";
        public string employeeNameInput = "//input[@id='attendance_employeeName_empName']";
        public string employeeNameInputText(string parameterForXPath)
        {
            return $"//li[text()='{parameterForXPath}']";
        }
 
        public string attendanceDate = "//input[@id='attendance_date']";
        public string viewBtn = "//a[@id='btView']";
        public string dateText(string parameterForXPath)
        {
            return $"//div[@aria-label='{parameterForXPath}']";
        }

        public string tableResults = "//*[@id='resultTable']//td";
        public string addBtn = "//div[@id='recordsTable']//*[@id='btnAdd']";
        public string textArea = "//textarea";
        public string punchInOutBtn = "//button[@id='btnPunchOutTrigger' or @id='btnPunchInTrigger']";
    }
}
